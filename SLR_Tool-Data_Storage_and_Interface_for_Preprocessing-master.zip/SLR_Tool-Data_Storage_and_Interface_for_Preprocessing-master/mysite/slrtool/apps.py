from django.apps import AppConfig


class SlrtoolConfig(AppConfig):
    name = 'slrtool'
